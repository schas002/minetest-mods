print("ho ver. 1/161222")

minetest.register_node("ho:cobblestone", {
  description = "Cobblestone",
  tiles = {
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png"
  },
  groups = {cracky = 3}
})

minetest.register_node("ho:grass", {
  description = "Grass block",
  tiles = {
    "ho_grass.png",
    "ho_grass.png",
    "ho_grass_side.png",
    "ho_grass_side.png",
    "ho_grass_side.png",
    "ho_grass_side.png"
  },
  groups = {crumbly = 2}
})

minetest.register_node("ho:dirt", {
  description = "Dirt",
  tiles = {
    "ho_dirt.png",
    "ho_dirt.png",
    "ho_dirt.png",
    "ho_dirt.png",
    "ho_dirt.png",
    "ho_dirt.png"
  },
  groups = {crumbly = 3}
})

minetest.register_node("ho:wooden_planks", {
  description = "Wooden planks",
  tiles = {
    "ho_wooden_planks.png",
    "ho_wooden_planks.png",
    "ho_wooden_planks.png",
    "ho_wooden_planks.png",
    "ho_wooden_planks.png",
    "ho_wooden_planks.png"
  },
  groups = {choppy = 3}
})

minetest.register_node("ho:stone", {
  description = "Stone",
  tiles = {
    "ho_stone.png",
    "ho_stone.png",
    "ho_stone.png",
    "ho_stone.png",
    "ho_stone.png",
    "ho_stone.png"
  },
  groups = {cracky = 2}
})
