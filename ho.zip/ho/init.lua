print("ho ver. 1/161222")

minetest.register_node("ho:cobblestone", {
  description = "Cobblestone",
  tiles = {
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png",
    "ho_cobblestone.png"
  },
  groups = {cracky = 3}
});

minetest.register_node("ho:grass", {
  description = "Grass block",
  tiles = {
    "ho_grass.png",
    "ho_grass.png",
    "ho_grass_side.png",
    "ho_grass_side.png",
    "ho_grass_side.png",
    "ho_grass_side.png"
  },
  groups = {crumbly = 3}
});
